// ex09B02.cpp
#include <iostream>
#include "CSolver.h"
using namespace std;

int main()
{
	CSolver equ1, equ2(1, 2, 3), *p;

	equ1.ShowEquation();
	equ1.ShowSolution(); cout << endl;

	equ2.Solve();
	equ2.ShowEquation();
	equ2.ShowSolution(); cout << endl;

	equ1.Set(0, 0, 3);
	equ1.Solve();
	equ1.ShowEquation();
	equ1.ShowSolution(); cout << endl;

	p = new CSolver(0, 2, 3);
	p->Solve();
	p->ShowEquation();
	p->ShowSolution(); cout << endl;

	p->Set(1, -4, 4);
	p->Solve();
	p->ShowEquation();
	p->ShowSolution(); cout << endl;
	delete p;

	equ1.Set(1, 2, -3);
	equ1.Solve();
	equ1.ShowEquation();
	equ1.ShowSolution(); cout << endl;
	
	equ1.Set(0, 0, 0);
	equ1.Solve();
	equ1.ShowEquation();
	equ1.ShowSolution();
	return 0;
}
