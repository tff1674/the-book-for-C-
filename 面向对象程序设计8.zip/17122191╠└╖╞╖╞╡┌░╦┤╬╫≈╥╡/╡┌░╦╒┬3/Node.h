  #ifndef MY_NODE_H
#define MY_NODE_H
#include <iostream>
 using namespace std;
  template <typename T> struct Node
   {
       T x;
        Node<T> *next;
        };
        template <typename T>
         void Create(Node<T> *&head, const T *array, int n)
         {
              Node<T> *p;
               if(head!=NULL) FreeList(head);
               for(int i=n-1; i>=0; i--)
               {
                    p = new Node<T>;
                    p->x = array[i];
                     p->next = head;
                     head = p;
               }
               }
               template <typename T>
               void ShowList(Node<T> *head)
               {
                   cout << "head";
                    while(head)
                    {
                        cout << " -> " << head->x;
                         head = head->next;
                    }
                     cout << " -> NULL" << endl;
               }
               template <typename T>
                void FreeList(Node<T> *&head)
                {
                     Node<T> *p;
                      while(head)
                      {
                           p = head;
                            head = head->next;
                             delete p;
                      }
                }
  #endif // MY_NODE_H Node<T> *p;


