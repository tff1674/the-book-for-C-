#include "Node.h"
template <typename T>
 void Sort(Node<T> *&head)
  {
       if(head==NULL) return;
        Node<T> *p, *rest, *pGuard;;
        rest = head->next;
          head->next = NULL;
          while(rest!=NULL)
          {
               p = rest;
               rest = rest->next;
               if(p->x <= head->x)
               {
                    p->next = head;
                     head = p;
               }
               else
               {
                    pGuard = head;
                    while(pGuard->next && pGuard->next->x < p->x)
                        pGuard = pGuard->next;
                    p->next = pGuard->next;
                     pGuard->next = p;
               }
               }
          }
 int main()
 {
      int iArray[] = {1, 3, 5, 7, 9, 2, 4, 5, 8, 10};
      Node<int> *iHead = NULL;
      Create(iHead,iArray,sizeof(iArray)/sizeof(*iArray));
       ShowList(iHead);
        Sort(iHead);
         ShowList(iHead); cout << endl;
          FreeList(iHead);
           double dArray[] = {3.14, 1.414, 2.718, 2.236, 1.414};
           Node<double> *dHead = NULL;
            Create(dHead,dArray,sizeof(dArray)/sizeof(*dArray));
             ShowList(dHead);
              Sort(dHead);
               ShowList(dHead); cout << endl;
                FreeList(dHead);
                char cArray[] = {'c', 'b', 'a', 'X', 'a', 'Y', 'Z'};
                 Node<char> *cHead = NULL;
                 Create(cHead,cArray,sizeof(cArray)/sizeof(*cArray));
                  ShowList(cHead);
                   Sort(cHead);
                    ShowList(cHead);
                    FreeList(cHead);
                     return 0;
 }
