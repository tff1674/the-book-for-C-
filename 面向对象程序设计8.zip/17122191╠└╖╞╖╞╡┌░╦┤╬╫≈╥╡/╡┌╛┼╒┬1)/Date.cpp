// Date.cpp
#include <iostream>
#include "Date.h"
using namespace std;

Date::Date(int year, int month, int day)
{
	y = year;
	m = month;
	d = day;
}

void Date::Set(int year, int month, int day)
{
	y = year;
	m = month;
	d = day;
}

int Date::GetYear() const
{
	return y;
}

int Date::GetMonth() const
{
	return m;
}

int Date::GetDay() const
{
	return d;
}

void Date::Show() const
{
	cout << y << '.' 
		 << m << '.' << d << endl;
}

void Date::NextDay()
{
	int days[] = {31,28,31,30,31,30,31,31,30,31,30,31};
	if((y%4==0 && y%100!=0) || y%400==0)
		days[1] = 29;
	d++;
	if(d>days[m-1])
	{
		d = 1;
		m++;
	}
	if(m>12)
	{
		m = 1;
		y++;
	}
}
