// ex09B01.cpp
#include <iostream>
#include "Date.h"
using namespace std;

int main()
{
	Date d;
	d.Show();
	d.Set(2000, 2, 28);
	cout << d.GetYear() << "��"
		 << d.GetMonth() << "��"
		 << d.GetDay() << "��" << endl;
	for(int i=0; i<3; i++)
	{
		d.NextDay();
		d.Show();
	}
	return 0;
}
