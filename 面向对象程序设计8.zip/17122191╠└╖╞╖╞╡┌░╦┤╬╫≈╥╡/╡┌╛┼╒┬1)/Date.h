// Date.h
#ifndef DATE_H
#define DATE_H

class Date
{
public:
	Date(int year=2010, int month=1, int day=1);
	void Set(int year, int month, int day);
	int GetYear() const;
	int GetMonth() const;
	int GetDay() const;
	void Show() const;
	void NextDay();
private:
	int y, m, d;
};

#endif
