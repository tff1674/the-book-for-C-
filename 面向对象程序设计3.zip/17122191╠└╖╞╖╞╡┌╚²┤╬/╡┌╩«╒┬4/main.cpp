#include <iostream>
#include <cstring>
#include <string>
using namespace std;
class Employee
{
	private :
		char *name; char *addr; char *zip;
	public :
		Employee ();
		Employee (char * Name="noName",char *Addr="noAddr",char *Zip="noZip");
		ChangeName (char *Name) ;
		void Display() const ;
};

	Employee::Employee(char * Name,char *Addr,char *Zip)
	{
		name=Name;
		addr=Addr;
		zip=Zip;
	}
	Employee::ChangeName (char *Name)
		{
			name=Name;
		}
	void Employee::Display() const
		{
			cout << name <<endl<<addr <<endl <<zip <<endl;
		}
int main()
{
	Employee s("��  ��","��ɽ· 18 ��","200020");
	Employee staff[3]={"��   ��",s,Employee("��  ��","����· 100 ��")};
	s.Display();
	for(int i=0;i<3;i++)
	{
		staff[i].Display();
	}
	s.ChangeName("��  ��");
	s.Display();
}
