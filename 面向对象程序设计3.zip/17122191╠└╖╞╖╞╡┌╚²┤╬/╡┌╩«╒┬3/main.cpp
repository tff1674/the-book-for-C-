#include <iostream>
#include <cstring>
#include <string>
using namespace std;
class Employee
{
	private :
		char name[20];char addr[20];char zip[20];
	public :
		Employee ();
		Employee (char * Name="noName",char *Addr="noAddr",char *Zip="noZip");
		ChangeName (char *Name) ;
		void Display() const ;
};

	Employee::Employee(char * Name,char *Addr,char *Zip)
	{
		strncpy(name,Name,sizeof(name));
		strncpy(addr,Addr,sizeof(addr));
		strncpy(zip,Zip,sizeof(zip));
	}
	Employee::ChangeName (char *Name)
		{
			strncpy(name,Name,sizeof(name));
		}
	void Employee::Display() const
		{
			cout << name <<endl<<addr <<endl <<zip <<endl;
		}
int main()
{
	Employee s("��  ��","��ɽ· 18 ��","200020");
	Employee staff[3]={"��   ��",s,Employee("��  ��","����· 100 ��")};
	s.Display();
	for(int i=0;i<3;i++)
	{
		staff[i].Display();
	}
	s.ChangeName("��  ��");
	s.Display();
}





