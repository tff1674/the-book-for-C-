#include <iostream>
#include <cstring>
#include <string>
#include <string.h>
using namespace std;
class Employee
{
	private :
		string name; string addr; string zip;
	public :
		Employee ();
		Employee (string Name="noName",string Addr="noAddr",string Zip="noZip");
		ChangeName (string Name) ;
		void Display() const ;
};

	Employee::Employee(string Name,string Addr,string Zip)
	{
		name=Name;
		addr=Addr;
		zip=Zip;
	}
	Employee::ChangeName (string Name)
		{
			name=Name;
		}
	void Employee::Display() const
		{
			cout << name << endl<< addr <<endl <<zip <<endl;
		}
int main()
{
	Employee s("��  ��","��ɽ· 18 ��","200020");
	Employee staff[3]={string ("��  ��"),s,Employee(string ("��  ��"),string ("����· 100 ��"))};

	s.Display();
	for(int i=0;i<3;i++)
	{
		staff[i].Display();
	}
	s.ChangeName("��  ��");
	s.Display();
}
