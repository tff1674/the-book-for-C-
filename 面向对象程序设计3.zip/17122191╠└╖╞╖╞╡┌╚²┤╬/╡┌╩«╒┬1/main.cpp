#include <iostream>

using namespace std;
class RMB
{
public:
    RMB();
    RMB(double);
    RMB(int,int,int);
    void Set(int yuan,int jiao,int fen){
        fen=fen%10;
        jiao=(jiao+fen/10)%10;
        yuan=yuan+(jiao+fen/10)/10;
    }
    void Display()
    {
        cout<<"���Ϊ"<<yuan<<"Ԫ"<<jiao<<"��"<<fen<<"��"<<endl;
    }
private:
    int yuan,jiao,fen;
};
RMB::RMB()
{

}
RMB::RMB(double value)
{
    yuan=(int)value;
    jiao=(int)((value-yuan)*10);
    fen=(int)(value*100-yuan*100-jiao*10);
}
RMB::RMB(int yuan,int jiao,int fen)
{
    fen=fen%10;
    jiao=(jiao+fen/10)%10;
    yuan=yuan+(jiao+fen/10)/10;
}
int main()
{
    RMB r1,r2(3,42,98),r3(1.548);
    r1.Set(53,24,15);
    r1.Display();
    r2.Display();
    r3.Display();
    return 0;
}
