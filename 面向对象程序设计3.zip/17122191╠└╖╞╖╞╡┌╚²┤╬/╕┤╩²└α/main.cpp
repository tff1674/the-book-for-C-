#include <iostream>
using namespace std;

class Complex
{
public:
	Complex(double r,double i);
	Complex operator+(const Complex &c);
	Complex operator-(const Complex &c);
	Complex operator*(const Complex &c);
	Complex operator/(const Complex &c);
	Complex operator+=(const Complex &c);
	Complex operator-=(const Complex &c);
	bool operator==(const Complex &c);

	void print(Complex &c);
private:
	double _real;
	double _image;
};

Complex::Complex(double r = 0.0, double i = 0.0)
{
	_real = r;
	_image = i;
}

//���������
Complex Complex:: operator + (const Complex &c)
{
	Complex tmp;
	tmp._real = _real + c._image;
	tmp._image = _image + c._image;
	return tmp;
}

//���������
Complex Complex::operator - (const Complex &c)
{
	Complex tmp;
	tmp._image = _image - c._image;
	tmp._real = _real - c._real;
	return tmp;
}

//���������(a+bi)(c+di)=(ac-bd)+(bc+ad)i
Complex Complex::operator*(const Complex &c)
{
	Complex tmp;
	tmp._real = _real*c._image - _image*c._real;
	tmp._image = _image*c._real + _real*c._image;
	return tmp;
}

//���������(ac+bd)/(c^2+d^2)+(bc-ad)/(c^2+d^2)i
Complex Complex :: operator/(const Complex &c)
{
	Complex tmp;
	double deno = c._real*c._real + c._image*c._image;//��������ķ�ĸdenominator
	tmp._real = deno*((_real*c._real) + (_image*c._image));
	tmp._image = deno*((_image*c._real) - (_real*c._image));
	return tmp;
}

Complex Complex::operator+=(const Complex &c)
{
	Complex tmp;
	tmp._real += c._real;
	tmp._image += c._image;
	return tmp;
}

Complex Complex::operator-=(const Complex &c)
{
	Complex tmp;
	tmp._real -= c._real;
	tmp._image -= c._image;
	return tmp;
}

bool Complex::operator==(const Complex &c)
{
	return(_real == c._real) && (_image == c._image);
}

void Complex::print(Complex &c)
{
	cout << c._real << "+ " << c._image << "i" << endl;
}

int main()
{
	Complex *c = NULL;
	Complex c1(9.0, 5.0);
	Complex c2(7.0, 6.0);
	Complex ret;
	cout << (c1 == c2) << endl;//���c1,c2�Ƿ����
	c->print(c1);//���c1+c2
	c->print(c2);
	cout << "c1+c2=";
	ret = c1 + c2;
	c->print(ret);

	return 0;
}
