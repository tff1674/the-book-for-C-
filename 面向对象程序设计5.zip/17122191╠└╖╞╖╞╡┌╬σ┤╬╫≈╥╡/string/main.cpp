#include <iostream>
#include <string.h>
#include<string>
#include<cstring>
using namespace std;
class Student
{
public:
    Student(string Name,string Number);
    void Change(string Name);
    void Display() const;
private:
    string name;
    string number;
};
Student::Student(string Name,string Number)
{
    name=Name,number=Number;
}
void Student::Change(string Name)
{
    name=Name;
}
void Student::Display()const
{
    cout<<name<<endl<<number<<endl;
}
int main()
{

    Student a("Tina","123");
    a.Change("Nana");
    a.Display();

    return 0;
}
