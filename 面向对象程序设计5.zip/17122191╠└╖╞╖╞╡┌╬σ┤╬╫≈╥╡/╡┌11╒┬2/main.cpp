#include <iostream>
#include <math.h>
using namespace std;

class point
{private:
        float x;
        float y;

 public:
        point():x(0),y(0){};
        point(float a,float b):x(a),y(b){};
        point(const point &p){ x=p.x; y=p.y;};

        virtual float distance(const point &p);
        virtual ~point(){};
};

float point::distance(const point &p)
{
        float d=sqrt(pow(p.x-x,2)+pow(p.y-y,2));
        return d;
}

int main()
{
 point a(2,3);
 point b(1,1);
 float res=a.distance(b);
 cout << res << endl;
 return 0;
}
