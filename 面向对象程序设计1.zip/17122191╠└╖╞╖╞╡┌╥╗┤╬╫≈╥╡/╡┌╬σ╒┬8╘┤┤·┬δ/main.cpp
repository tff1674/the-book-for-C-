#include <iostream>
#include<cstring>
using namespace std;
void StrSwap(char str1[100],char str2[100]){
    char t;
    t=str1[100];str1[100]=str2[100];str2[100]=t;
}
int main()
{
    char str1[100]="I'm a programmer.";
    char str2[100]="Hello, world.";
    cout << str1<<'\n'<<str2 << endl;
    StrSwap(str1,str2);
    cout<<str1<<'\n'<<str2<<endl;
    return 0;
}
