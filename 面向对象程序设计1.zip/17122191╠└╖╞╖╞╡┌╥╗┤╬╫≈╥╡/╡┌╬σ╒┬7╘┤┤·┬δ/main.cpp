#include <iostream>

using namespace std;
void exchange(char *&p1,char *&p2){
    char *t=NULL;
    t=p1;p1=p2;p2=t;
}
int main()
{
    char *p1="I'm a programmer.";
    char *p2="Hello, world.";
    cout <<p1<<'\n'<<p2<< endl;
    exchange(p1,p2);
    cout<<p1<<'\n'<<p2<<endl;
    return 0;
}
