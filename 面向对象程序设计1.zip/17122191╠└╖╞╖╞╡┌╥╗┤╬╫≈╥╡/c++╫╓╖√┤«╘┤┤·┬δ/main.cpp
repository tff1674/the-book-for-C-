#include <iostream>
#include<cstring>
using namespace std;
void change(char*s)
{
    int len=strlen(s);int i;
     for(i=0;i<len;i++){
            if(s[i]>='a'&&s[i]<='z'){
            s[i]=s[i]-'a'+'A';}
     }
}
int main()
{
    char s[100];
    cin>>s;
    change(s);
    cout <<s<< endl;
    return 0;
}
