#include<iostream>
#include<cmath>
using namespace std;

class QEquation{
double a,b,c;
public:
  QEquation(double x, double y, double z){
  a=x; b=y; c=z;
}
void set_coef(double x, double y, double z){
   a=x; b=y; c=z;
}
void solve_equation(){
  double d,x1,x2;
  d=b*b-4*a*c;
if(d>0){
  d=sqrt(d);
  x1=(-b+d)/(2*a);
  x2=(-b-d)/(2*a);
  cout <<"x1=" <<x1 <<", x2=" <<x2 <<endl;
}
  else if(d==0){
    x1=-b/(2*a);
    cout <<"x1=x2=" <<x1 <<endl;
}else
cout <<"No Solution.\n";
}
};
int main(){
   QEquation e1,e2(2,4,8),e3;
   e3.set_coef(1,4,4);
   e1.solve_equation();
   e2.solve_equation();
   e3.solve_equation();
return 0;
}
