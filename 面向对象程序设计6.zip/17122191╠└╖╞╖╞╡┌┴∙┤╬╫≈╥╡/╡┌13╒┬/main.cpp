#include <iostream>
#include <cmath>
using namespace std;

const long double PI = 3.1415926;

class Circle
{
public:
    virtual long double GetSuperficialArea() = 0;      //��ñ����
    virtual long double GetVolume() = 0;                   //������
private:
};

//��
class Ball:public Circle
{
public:
    Ball(long double radius):m_radius(radius)
    {
    }

    long double GetVolume()
    {
        return 4.0/3.0 * PI * m_radius * m_radius * m_radius;
    }

    long double GetSuperficialArea()
    {
        return 4 * PI * m_radius * m_radius;
    }
protected:
private:
    long double m_radius;                                 //��İ뾶
};

//Բ��
class Cylinder:public Circle
{
public:
    Cylinder(long double radius, long double high):m_radius(radius),m_high(high)
    {
    }

    long double GetVolume()
    {
        return PI * m_radius * m_radius * m_high;
    }

    long double GetSuperficialArea()
    {
        return PI * m_radius * m_radius + 2.0 * PI * m_radius * m_high;
    }
protected:
private:
    long double m_radius;                                 //Բ���İ뾶
    long double m_high;                                       //Բ���ĸ�

};

//Բ׶
class Taper :public Circle
{
public:
    Taper (long double radius, long double high):m_radius(radius),m_high(high)
    {
        this->m_coneElement = sqrt(m_high * m_high + m_radius * m_radius);
    }

    long double GetVolume()
    {
        return 1.0/3.0 * PI * m_radius * m_radius * m_high;
    }

    long double GetSuperficialArea()
    {
        return PI * m_radius * (m_radius + m_coneElement);
    }
protected:
private:
    long double m_radius;                                 //Բ׶�İ뾶
    long double m_high;                                       //Բ׶�ĸ�
    long double m_coneElement;                                //Բ׶��ĸ�߳�

};

int main()
{
    Circle *p = NULL;
    p = new Taper (3,4);
    cout << "Բ׶(3,4)�ı�����ǣ�" << p->GetSuperficialArea() << " ����ǣ�" << p->GetVolume() << endl;
    delete p;
    p = NULL;

    p = new Cylinder(6,4);
    cout << "Բ��(6,4)�ı�����ǣ�" << p->GetSuperficialArea() << " ����ǣ�" << p->GetVolume() << endl;
    delete p;
    p = NULL;

    p = new Ball(6);
    cout << "��(6)�ı�����ǣ�" << p->GetSuperficialArea() << " ����ǣ�" << p->GetVolume() << endl;
    delete p;
    p = NULL;


    return 0;
}
