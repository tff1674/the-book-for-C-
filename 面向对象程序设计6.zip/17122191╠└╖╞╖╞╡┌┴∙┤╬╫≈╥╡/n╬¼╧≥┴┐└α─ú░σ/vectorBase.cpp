#include <iostream>
using namespace std;

// for any dimensions other than
// specified below, this struct will
// be used
template<class T,int N>


// specialization for a 2D vector
// provides the vector with .x and .y variables
template<class T>
struct vector_base<T, 2>
{
    union
    {
        struct
        {
            T x, y;
        };
        T m_data[2];
    };

    vector_base() { }
    vector_base( const T& _x, const T& _y ) : x(_x), y(_y) { }
};

// specialization for a 3D vector
// provides the vector with .x, .y, and .z variables
template<class T>
struct vector_base<T,3>
{
    union
    {
        struct
        {
            T x, y, z;
        };
        T m_data[3];
    };

    vector_base() { }
    vector_base( const T& _x, const T& _y, const T& _z ) : x(_x), y(_y), z(_z) { }
};

// specialization for a 4D vector
// provides the vector with .w, .x, .y, and .z variables
template<class T>
struct vector_base<T,4>
{
    union
    {
        struct
        {
            T w, x, y, z;
        };
        T m_data[4];
    };

    vector_base() { }
    vector_base( const T& _w, const T& _x, const T& _y, const T& _z ) : w(_w), x(_x), y(_y), z(_z) { }
};

// a base for a vector that doesn't specialize vector_base
// provides the vector with .r, .g, .b, and .a variables
template<class T>
struct vector_color
{
    union
    {
        struct
        {
            T r, g, b, a;
        };
        T m_data[4];
    };
    vector_color() { }
    vector_color( const T& _r, const T& _g, const T& _b, const T& _a ) : r(_r), g(_g), b(_b), a(_a) { }
};
