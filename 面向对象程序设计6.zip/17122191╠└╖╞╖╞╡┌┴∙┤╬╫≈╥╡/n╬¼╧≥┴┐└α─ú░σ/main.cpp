#include "vectorBase.cpp"
#include "vectorTemplate.cpp"

int main( int c, char* v[] )
{
    //
    // the vector_t declaration is already looking ugly,
    // provide some typedefs:
    //

    // simple geometric types:
    typedef vector_t<double,2>    v2;
    typedef vector_t<int,2>       v2i;

    // graphics specific color types:
    typedef unsigned char       ui8;
    typedef vector_t<float, 4, vector_color<float> >    colorf;
    typedef vector_t<int, 4, vector_color<int> >        colori;
    typedef vector_t<ui8, 4, vector_color<ui8> >        color;

    //
    // begin some tests:
    //

    //
    // test 1:
    //
    {
        std::cout << "test1:/n";

        v2 pt1_d = v2( 3.0, 3.0 );
        v2i pt2_i( 1, 2 );

        v2 pt2 = (pt1_d + pt2_i) * 0.5;

        std::cout << pt2 << "/n/n";
    }

    //
    // test 2:
    //
    {
        std::cout << "test2:/n";

        //  v2 pt1 = v2( 1.0, 2.0, 3.0 ); // C2661: no overloaded function takes three arguments

        v2 pt1 = v2( 1.0, 2.0 );
        v2i pt2i = v2i( 3, 4 );

        v2 pt3( pt1 ); // test copy constructor
        std::cout << pt3 << '/n';

        pt3 = pt1;  // test assignment operator
        std::cout << pt3 << '/n';

        pt3 = pt2i; // test assignment operator
        std::cout << pt3 << '/n';

        pt3.y = pt3.x; // test aliases

        std::cout << "/n/n";
    }

    //
    // test 3:
    //
    {
        std::cout << "test3:/n";

        colorf my_color( 0.0, 1.0, 0.5, 1.0 );
        std::cout << my_color << '/n';

        // test alias:
        my_color.r = 0.25;

        std::cout << my_color << '/n';

        color hardware_color( my_color * 255 );
        std::cout << colori( hardware_color ) << '/n'; // cast to int to display ints instead of chars

        std::cout << "/n/n";
    }

    //
    // test 4:
    //
    {
        std::cout << "test4:/n";
        typedef vector_t<double,5>    v5;

        // vector_t doesn't have a five arg constructor, so
        // we will have to use arrays, (or just implement a 5-arg constructor)

        double arr[] = { 1.0, 2.0, 3.0, 4.0, 5.0 };

        v5 p1( arr );
        v5 p2 = arr;

        std::cout << p1 << '/n' << p2 << '/n' << (p1 + p2).normalize() << '/n';

        //  v5 p3( { 1.0, 2.0, 3.0, 4.0, 5.0 } );  // error :(
        std::cout << "/n/n";
    }

    system("PAUSE");
    return 0;
}
