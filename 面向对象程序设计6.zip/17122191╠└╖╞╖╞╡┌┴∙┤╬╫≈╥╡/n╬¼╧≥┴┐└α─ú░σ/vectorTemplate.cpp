#include <cassert>
#include <cmath>

#include "vectorBase.cpp"

// the vector itself
// with its variable type: T
// its dimensions: N
// and its core: base
template<class T, int N, class base = vector_base<T,N> >
class vector_t : public base
{
public:
    // handy typedef:
    typedef vector_t<T,N> my_type;

    // default constructor
    vector_t() { }

    // two-arg constructor for 2D vectors
    vector_t( const T& x, const T& y ) : base(x,y) { }

    // three-arg constructor for 3D vectors
    vector_t( const T& x, const T& y, const T& z ) : base(x,y,z) { }

    // four-arg constructor for 4D vectors
    vector_t( const T& w, const T& x, const T& y, const T& z ) : base(w,x,y,z) { }

    //
    //  Note, if the programmer tries to construct a 3D vector using a two-arg constructor,
    //  the compiler will complain that base does not have enough arguments.  Nifty :)
    //

    // constructor for same-dimensional, differing-typed vectors
    // use the keyword "explicit"
    template<class T2, class B2>
    vector_t( const vector_t<T2,N,B2>& rhs )
    {
        for ( int i = 0; i < N; i++ )
            m_data[i] = static_cast<T>( rhs.m_data[i] );
    }

    // constructor with a same-dimensional array of a differing type
    template<class T2>
    // vector_t( const T2 data[N] )
    vector_t( const T2 (&data)[N] )
    {
        for ( int i = 0; i < N; i++ )
            m_data[i] = static_cast<T>( data[i] );
    }

    // assignment operation for same-dimensional, differing-typed vectors
    template<class T2, class B2>
    my_type& operator = ( const vector_t<T2,N,B2>& rhs )
    {
        for ( int i = 0; i < N; i++ )
            m_data[i] = static_cast<T>( rhs.m_data[i] );
        return *this;
    }

    // assignment operation for a an array of a differing type
    template<class T2>
    my_type& operator = ( const T2 data[N] )
    {
        for ( int i = 0; i < N; i++ )
            m_data[i] = static_cast<T>( data[i] );
        return *this;
    }

    //
    // getters
    //
    T& operator [] ( const int idx )
    {
        assert( 0 <= idx && idx < N );    // or throw an exception
        return m_data[ idx ];
    }

    const T& operator [] ( const int idx ) const
    {
        assert( 0 <= idx && idx < N );
        return m_data[ idx ];
    }


    //
    // overloads
    //

    // negation
    my_type operator - () const
    {
        my_type result;
        for ( int i = 0; i < N; i++ )
            result.m_data[i] = -m_data[i];
        return result;
    }

    // addition of two same-dimensional, differing-typed vectors
    template<class T2,class B2>
    my_type operator + ( const vector_t<T2,N,B2>& rhs ) const
    {
        my_type result;
        for ( int i = 0; i < N; i++ )
            result.m_data[i] = m_data[i] + rhs.m_data[i];
        return result;
    }

    // subtraction of two same-dimensional, differing-typed vectors
    template<class T2,class B2>
    my_type operator - ( const vector_t<T2,N,B2>& rhs ) const
    {
        my_type result;
        for ( int i = 0; i < N; i++ )
            result.m_data[i] = m_data[i] - rhs.m_data[i];
        return result;
    }

    // scalar multiplication of two same-dimensional, differing-typed vectors
    template<class T2>
    my_type operator * ( const T2& rhs ) const
    {
        my_type result;
        for ( int i = 0; i < N; i++ )
            result.m_data[i] = static_cast<T>( m_data[i] * rhs );
        return result;
    }

    // scalar division of two same-dimensional, differing-typed vectors
    template<class T2>
    my_type operator / ( const T2& rhs ) const
    {
        my_type result;
        for ( int i = 0; i < N; i++ )
            result.m_data[i] = m_data[i] / rhs;
        return result;
    }


    //
    // operations:
    //

    // calculate the dot product of two differing-typed vectors
    template<class T2,class B2>
    T dot( const vector_t<T2,N,B2>& rhs ) const
    {
        T result = static_cast<T>( 0 );
        for ( int i = 0; i < N; i++ )
            result += static_cast<T>( m_data[i] * rhs.m_data[i] );
        return result;
    }

    // squared length of the vector
    T length_sq() const
    {
        return this->dot( *this );
    }

    // length of the vector
    T length() const
    {
        return std::sqrt( this->dot( *this ) );
    }

    // return a normalized vector
    my_type normalize() const
    {
        return *this / this->length();
    }

    // and for other operations not mentioned,
    // you can provide a functor to do the rest
    template<class F>
    my_type predicate( const F& f ) const
    {
        my_type result;
        for ( int i = 0; i < N; i++ )
            result.m_data[i] = f( m_data[i] );
        return result;
    }
};

// handy write to ostream function:
template<class T, int N, class B>
std::ostream& operator << ( std::ostream& out, const vector_t<T,N,B>& v )
{
    for ( int i = 0; i < N; i++ )
        out << v.m_data[ i ] << ' ';
    return out;
}
