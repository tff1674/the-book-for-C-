#include <iostream>
using namespace std;
class money //����money��
{
public: //���ݳ�ԱΪ���õ�
int yuan;
int jiao;
int fen;
money( int y = 0, int j = 0, int f = 0 ) ;
money operator ++ ( ) ;
money operator ++ ( int ) ;
void display () { cout << yuan <<" yuan " << jiao <<" jiao " << fen << " fen " << endl ; } ;
};

money :: money ( int y, int j, int f ): yuan (y) , jiao ( j ) , fen ( f ) {}

money money :: operator ++ ()
{
if( ++fen >= 10 )
{
fen -= 10 ;
++jiao;
}
return * this ;
}
money money :: operator ++ ( int )
{
money temp ( *this ) ;
fen ++;
if (fen >= 10 )
{
fen -= 10 ;
++jiao;
}
return temp ;
}

int main( )
{
money m1 (10 , 8 , 5 ), m2 , m3;
cout<< " m1 : " ;
m1.display ( ) ;
m2 = ++m1 ;
m2.display( ) ;
m3 = m1++ ;
m3.display( ) ;
return 0;
}
