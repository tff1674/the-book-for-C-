#include <iostream>
using namespace std;

class Time
{
public:
Time();
Time(int h, int m ,int s);
Time operator +(Time &t1);
Time operator >>(Time &t1);
Time operator <<(Time &t1);

void setHour(int h )
{
hour=h;
}
void setMinute(int m)
{
minute=m;
}
void setSecond(int s)
{
second=s;
}
int getHour()
{
return hour;
}
int getMinute()
{
return minute;
}
int getSecond()
{
return second;
}
private:
int hour;
int minute;
int second;

};
Time::Time()
{
hour=0;
minute=0;
second=0;
}
Time::Time(int h, int m ,int s)
{
hour=h;
minute=m;
second=s;
}
Time Time::operator +(Time &t1)
{
return Time(hour+t1.getHour(),minute+t1.getMinute(),second+t1.getSecond());
}
Time Time::operator >>(Time &t1)
{
int a,b,c;
cout<<"inputTime1:"<<endl;
cin>>a>>b>>c;
hour=a;
minute=b;
second=c;
cout<<"inputTime2:"<<endl;
cin>>a>>b>>c;
t1.setHour(a);
t1.setMinute(b);
t1.setSecond(c);
return Time(hour+t1.getHour(),minute+t1.getMinute(),second+t1.getSecond());
}
Time Time::operator <<(Time &t1)
{

cout<<t1.getHour()<<':'<<t1.getMinute()<<':'<<t1.getSecond()<<endl;
return Time(hour+t1.getHour(),minute+t1.getMinute(),second+t1.getSecond());

}

int main()
{
Time time1(1,2,3);
Time time2(2,3,4);
Time time3;
time3 = time1+time2;
time3 = time1>>time2;

}
