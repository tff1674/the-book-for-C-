#include <iostream>

using namespace std;
template <typename T> void ShowTypeSize(const char*type, T x)
{
    int n;
    n=sizeof(x);
    cout<<"sizeof("<<type<<"):"<<' '<<n<<"byte(s)"<<endl;

}
int main()
{
    ShowTypeSize("int",int(1));
    ShowTypeSize("double",double(1));
    ShowTypeSize("char",char(1));
    ShowTypeSize("long",long(1));
    return 0;
}
