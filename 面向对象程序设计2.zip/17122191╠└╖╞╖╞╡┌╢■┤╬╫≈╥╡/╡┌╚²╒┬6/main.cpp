#include<iostream>
#include<iomanip>
using namespace std;
int main(){
int i,j,s;
for(i=1;i<10;i++)
{
	for(j=1;j<i+1;j++){
		s=i*j;
		cout<<j<<'*'<<i<<'='<<s<<' ';
	}
	cout<<'\n'<<endl;
}
for(i=1;i<10;i++)
{
  for(j=1;j<10;j++){
        if(i<=j)
        cout<<i<<'*'<<j<<'='<<setw(2)<<i*j<<' ';
        else
        cout<<setw(7)<<' ';
  }
        cout<<'\n'<<endl;
}
return 0;
}
