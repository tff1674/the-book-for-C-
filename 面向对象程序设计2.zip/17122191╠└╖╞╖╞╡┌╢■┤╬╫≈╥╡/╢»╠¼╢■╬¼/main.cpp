#include <iostream>
using namespace std;
int main()
{
   int x,y;
   int i,n,k;
   x=3;
   y=4;
   int **p;
   p = new int*[x];
   for(i=0; i<x;i++)
{
   p[i] = new int [y];
}

   k=0;
   for(i=0;i<x;i++)
{
     for(n=0;n<y;n++)
{
     p[i][n] = k;
     k++;
}
}

   for(i=0;i<x;i++)
{
    for(n=0;n<y;n++)
{
      cout << p[i][n] << "\t";
}
    cout << endl;
}

    for(i=0;i<x;i++)
{
    delete [] p[i];
}
    delete [] p;
return 0;
}
