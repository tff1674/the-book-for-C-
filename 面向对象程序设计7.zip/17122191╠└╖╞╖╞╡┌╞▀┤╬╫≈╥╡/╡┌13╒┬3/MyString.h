#ifndef MYSTRING_H
 #define MYSTRING_H
 #include <cstring >
 #include <string >
 #include "Vector.h"

 class String : public VECTOR <char>
{
public:
 String(const char *x="") : VECTOR <char>(strlen(x), x)
 { }

 void Output(ostream &out) const
 {
 for(int i=0; i<num; i++)
out << p[i];
 }

 void Input(istream &in)
 {
 string temp;
 getline(in, temp);
 *this = temp.c_str();
 }

 String operator+(const String &str)
 {
 int i, j;
 String temp;
 temp.num = num + str.num;
 temp.p = new char[temp.num];
for(i=0; i<num; i++)
 temp.p[i] = p[i];
 for(j=0; j<str.num; j++)
 temp.p[i+j] = str.p[j];
 return temp;
 }
 };
 #endif
