#ifndef VECTOR_H
 #define VECTOR_H
 #include "Vector.h"

template <typename T> class Vector : public VECTOR <T>
 {
 public:
 Vector(int size=0,const T *x=NULL):VECTOR <T>(size, x)
 { }

 void Output(ostream &out) const
 {
 if (num==0) out << "( )";
 else
 {
 out << "(" << p[0];
 for(int i=1; i<num; i++)
 out << ", " << p[i];
 out << ")";
 }
}

 void Input(istream &in)
 {
 char c;
 T x;
 resize(0);
 in >> c;
 if (c!='(') return ;
 while(in >> x)
 {
resize(num+1);
 p[num-1] = x;
 in >> c;
 if (c==')') break;
 }
 if (in.fail())
 {
 in.clear();
 in.sync();
 }
 }

 Vector operator+(const Vector &v)
{
Vector result;
 if (num == v.num)
 {
 result.resize(num);
 for(int i=0; i<num; i++)
 result[i] = p[i] + v.p[i];
 }
 return result;
 }
};
 #endif
