
 #include <iostream >
 #include <string >
 using namespace std;


 #define VIRTUAL 0
 class Animal
{
 public:
 Animal(string Name="Noname")
{
 name = Name;
 }
 # if (VIRTUAL==0)
void Sound() const {}
 #elif(VIRTUAL==1)
virtual void Sound() const {}
 virtual ~Animal() {}
 #else
 virtual void Sound() const = 0;
 virtual ~Animal() {}
#endif
 void ShowName(ostream &out) const
 {
 out << name;
 }
 private:
 string name;
 };

 void Speaker(const Animal &a)
 {
 a.ShowName(cout); cout << "\t";
 a.Sound(); cout << endl;
 }

 void Speaker(const Animal *a)
 {
 a->ShowName(cout); cout << "\t";
 a->Sound(); cout << endl;
 }


 #if (VIRTUAL!=2)
 void Speaker1(Animal a)
 {
 a.ShowName(cout); cout << "\t";
 a.Sound(); cout << endl;
}
 #endif

 class Cat : public Animal
 {
 public:
 Cat(string Name="è") : Animal(Name) {}
 void Sound() const
 {
cout << "miaow ...";
 }
 };

 class Dog : public Animal
 {
 public:
 Dog(string Name="��") : Animal(Name) {}
 void Sound() const
{
 cout << "wang ...";
 }
 };

 class Rooster : public Animal
 {
 public:
 Rooster(string Name="��") : Animal(Name) {}
 void Sound() const
{
 cout << "crow ...";
 }
 };

 class Cattle : public Animal
 {
 public:
 Cattle(string Name="ţ") : Animal(Name) {}
 void Sound() const
 {
 cout << "moo ...";
}
 };

 class Horse : public Animal
 {
 public:
 Horse(string Name="��") : Animal(Name) {}
 void Sound() const
 {
 cout << "neigh ...";
 }
 };

 int main()
 {
 Cat c;
 Dog d;
 Rooster r;
 Cattle a;
 Horse h;

 cout << "\n ���ô��ݶ���\t";
 Speaker(c);
 cout << "��ֵַ����\t";
 Speaker(&c);
 # if (VIRTUAL!=2)
 cout << "ֵ���ݶ���\t";
 Speaker1(c);
 #endif

 cout << "\n ���ô��ݶ���\t";
 Speaker(d);
 cout << "��ֵַ����\t";
 Speaker(&d);
 # if (VIRTUAL!=2)
 cout << "ֵ���ݶ���\t";
Speaker1(d);
 #endif
cout << "\n ���ô��ݶ���\t";
 Speaker(r);
 cout << "��ֵַ����\t";
 Speaker(&r);
 # if (VIRTUAL!=2)
cout << "ֵ���ݶ���\t";
 Speaker1(r);
 #endif
 cout << "\n���ô��ݶ���\t";
 Speaker(a);
 cout << "��ֵַ����\t";
 Speaker(&a);
 # if (VIRTUAL!=2)
 cout << "ֵ���ݶ���\t";
 Speaker1(a);
#endif

 cout << "\n���ô��ݶ���\t";
 Speaker(h);
cout << "��ֵַ����\t";
 Speaker(&h);
# if (VIRTUAL!=2)
cout << "ֵ���ݶ���\t";
 Speaker1(h);
 #endif
return 0;
}
